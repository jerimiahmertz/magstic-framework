


Strategy Canvas — Phase 2










Project: [Project Name]










Date: [Date]










Linked Goals: [Reference Objective 1, 2, 3 from Phase 1]












Target Segments










Primary Segment: [Segment Name]
















Field


Description










Who


[Role, title, demographic, or firmographic description]






Size


[Estimated addressable population]






Current Behavior


[How they solve the problem today]






Pain Points


[Top 2-3 frustrations with current state]






Switching Trigger


[What would cause them to change]






Switching Cost


[What makes it hard to change]










Secondary Segment: [Segment Name]
















Field


Description










Who


[Description]






Size


[Estimate]






Current Behavior


[Current solution]






Pain Points


[Frustrations]






Switching Trigger


[Change catalyst]






Switching Cost


[Barriers]












Value Proposition










Jobs-to-Be-Done
















Job Type


Job Statement


Importance


Satisfaction (Current)










Functional


[What they need to accomplish]


High/Med/Low


High/Med/Low






Emotional


[How they want to feel]


High/Med/Low


High/Med/Low






Social


[How they want to be perceived]


High/Med/Low


High/Med/Low










Value Proposition Statement










For
 [target segment], 
who
 [need/job], 
our
 [product/initiative] 
is a
 [category] 
that
 [key benefit]. 
Unlike
 [alternatives], 
we
 [key differentiator].





Competitive Landscape










Positioning Matrix



















[Dimension A] →


[Dimension A] →











[Dimension B] ↑



[Competitor X]


[Our Position]







[Dimension B] ↓



[Competitor Y]


[Competitor Z]










Alternative Solutions Comparison
















Alternative


Strengths


Weaknesses


Our Advantage










[Alt 1]















[Alt 2]















[Alt 3 - Status Quo]





















Strategic Moat Assessment (Helmer's 7 Powers)
















Power


Applicable?


Evidence / Plan










Scale Economies


Y/N


[Description]






Network Effects


Y/N


[Description]






Counter-Positioning


Y/N


[Description]






Switching Costs


Y/N


[Description]






Branding


Y/N


[Description]






Cornered Resource


Y/N


[Description]






Process Power


Y/N


[Description]












Strategic Risks & Assumptions
















#


Assumption


Confidence


How to Validate










1


[What must be true]


High/Med/Low


[Validation method]






2















3

























#


Risk


Likelihood


Impact


Mitigation










1


[Strategic risk]


H/M/L


H/M/L


[Mitigation]






2


















3
























Phase 2 Complete — Ready for Tactics Phase →







Tactics Plan — Phase 3










Project: [Project Name]










Date: [Date]










Linked Strategy: [Target Segment + Value Prop from Phase 2]












Marketing & Product Mix










Product
















Tactic


Description


Rationale


Strategic Link


Priority










[Tactic]


[What we build/modify]


[Why this delivers value]


[Which strategic choice]


P0/P1/P2





























Price
















Tactic


Description


Rationale


Strategic Link


Priority










[Tactic]


[Pricing model/change]


[Why this structure]


[Which strategic choice]


P0/P1/P2





























Incentives
















Tactic


Description


Rationale


Strategic Link


Priority










[Tactic]


[Adoption driver]


[Why this accelerates uptake]


[Which strategic choice]


P0/P1/P2





























Communication
















Tactic


Description


Rationale


Strategic Link


Priority










[Tactic]


[Messaging/channel]


[Why this reaches target]


[Which strategic choice]


P0/P1/P2





























Distribution
















Tactic


Description


Rationale


Strategic Link


Priority










[Tactic]


[Delivery mechanism]


[Why this channel]


[Which strategic choice]


P0/P1/P2































Traceability Matrix
















Tactic


→ Strategic Choice


→ Goal/Objective










[Tactic 1]


[Strategy element]


[Objective #]






[Tactic 2]


[Strategy element]


[Objective #]






[Tactic 3]


[Strategy element]


[Objective #]












Prioritization










Method Used:
 [RICE / ICE / MoSCoW — state why this method fits]









Tactic


Reach


Impact


Confidence


Effort


Score


Rank










[Tactic 1]
























[Tactic 2]
























[Tactic 3]






























Quick Wins vs. Strategic Bets










Quick Wins (High Impact, Low Effort)











[Tactic] — [Why it's quick, what it unlocks]


[Tactic] — [Why it's quick, what it unlocks]





Strategic Bets (High Impact, High Effort)











[Tactic] — [Why it's worth the investment, expected payoff timeline]


[Tactic] — [Why it's worth the investment, expected payoff timeline]





Deprioritized (Low Impact or Premature)











[Tactic] — [Why not now, when to reconsider]







Dependencies
















Tactic


Depends On


Blocked By


Notes










[Tactic]


[Prerequisite]


[Blocker if any]































Phase 3 Complete — Ready for Implementation Phase →



